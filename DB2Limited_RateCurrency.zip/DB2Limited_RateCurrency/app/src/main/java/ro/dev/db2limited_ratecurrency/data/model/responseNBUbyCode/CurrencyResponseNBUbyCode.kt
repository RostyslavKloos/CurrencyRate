package ro.dev.db2limited_ratecurrency.data.model.responseNBUbyCode

class CurrencyResponseNBUbyCode : ArrayList<CurrencyResponseNBUbyCodeItem>()