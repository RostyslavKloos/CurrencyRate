package ro.dev.db2limited_ratecurrency.data.model.responseNBU

class CurrencyResponseNBU : ArrayList<CurrencyResponseItemNBU>()